﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TextBasedCalculator
{
    class TestCalculator
    {
        static void IntroductoryDetails()
        {
            Console.WriteLine("Text Based Calculator");
            Console.WriteLine("Ensure the following:");
            Console.WriteLine("1. Each Line will contain a series of strings separated by space. Ex: i = 10; k = i + j");
            Console.WriteLine("If want to view the final result, Please click on <Enter>");
        }

        static void Main(string[] args)
        {
            IntroductoryDetails();

            TextCalculator calculate = new TextCalculator();

            calculate.Calculate();

            calculate = null;
        }
    }
}
