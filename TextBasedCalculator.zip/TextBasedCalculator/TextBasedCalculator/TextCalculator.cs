﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace TextBasedCalculator
{
    class TextCalculator
    {
        static Dictionary<String, Int32> inputCharacters;
        
        #region CALCULATE

        public void Calculate()
        {
            String input;
            String[] nwString = null;
            try
            {
                inputCharacters = new Dictionary<String, Int32>();

                input = Console.ReadLine();

                while (input != null && input.Length > 0)
                {
                    nwString = input.Split(' ');

                    if (nwString.Length < 3)
                    {
                        Console.WriteLine("Not A Valid Input!..Please, Enter A Valid Input.");
                    }
                    else
                    {
                        if (ValidateInput(nwString))
                        {
                            bool checkMultipleOperations = CheckMultipleOperators(nwString[1]);

                            if (checkMultipleOperations)
                            {
                                //Check if nwString[0] is initialized
                                if (!inputCharacters.ContainsKey(nwString[0]))
                                {
                                    Console.WriteLine(nwString[0] + " is not yet initialized");
                                }
                                else
                                {
                                    String[] gtNewString = GetNewString(nwString);

                                    SetValueInDictionary(nwString[0], EvaluatePostFixExpression(gtNewString));

                                    gtNewString = null;
                                }
                            }
                            else
                            {
                                SetValueInDictionary(nwString[0], EvaluatePostFixExpression(nwString));
                            }
                        }
                        else
                        {
                            Console.WriteLine("Not A Valid Input!..Please, Enter A Valid Input.");
                        }
                    }

                    input = Console.ReadLine();
                
                }

                Display();
            }
            catch (Exception)
            {
                Console.WriteLine("Problem Occurred While Performing An Operation..Try Again Later");
            }
            finally
            {
                input = null;
                nwString = null;
            }
        }

        #endregion

        #region SET VALUES

        void SetValueInDictionary(String key, Int32 value)
        {
            if (inputCharacters != null && key != null)
            {
                if (inputCharacters.ContainsKey(key))
                {
                    inputCharacters[key] = value;
                }
                else
                {
                    inputCharacters.Add(key, value);
                }
            }
        }

        #endregion

        #region GENERATENEWSTRING

        String[] GetNewString(String[] input)
        {
            String[] nwString = null;

            if (input != null && input.Length > 0)
            {
                nwString = new String[input.Length + 2];
                
                nwString[0] = input[0];
                nwString[1] = "=";
                nwString[2] = input[0];
                nwString[3] = input[1].ToCharArray()[0].ToString();

                for (int i = 2; i < input.Length; i++)
                {
                    nwString[2+i] = input[i];
                }
            }

            return nwString;
        }

        #endregion

        #region VALIDATION

        bool CheckIncrementDecrementOperator(String isIncrementDecrement)
        {
            return (isIncrementDecrement.Contains("++") || isIncrementDecrement.Contains("--"));
        }

        bool CheckMultipleOperators(String isOperator)
        {
            return (isOperator.Contains("+=") || isOperator.Contains("-=") || isOperator.Contains("*=") || isOperator.Contains("/=") || isOperator.Contains("%="));
        }

        bool CheckArithmetic(string isArithmetic)
        {
            return (isArithmetic == "+" || isArithmetic == "-" || isArithmetic == "*" || isArithmetic == "/" || isArithmetic == "%");
        }

        int Precedence(string checkOperatorPrecedence)
        {
            if (checkOperatorPrecedence.Equals("+") || checkOperatorPrecedence.Equals("-"))
            {
                return 1;
            }

            if (checkOperatorPrecedence.Equals("*") || checkOperatorPrecedence.Equals("/") || checkOperatorPrecedence.Equals("%"))
            {
                return 2;
            }

            return -1;
        }

        bool ValidateInput(String[] input)
        {
            if (!Regex.IsMatch(input[0], @"^[a-zA-Z]+$"))
            {
                return false;
            }

            for (int i = 1; i < input.Length; i++)
            {
                bool checkInput = (input[i] != "=");

                checkInput = checkInput && !CheckArithmetic(input[i]);

                checkInput = checkInput && !CheckMultipleOperators(input[i]);

                checkInput = checkInput && !CheckIncrementDecrementOperator(input[i]);

                checkInput = checkInput && !Regex.IsMatch(input[i], @"^[a-zA-Z]+$");

                checkInput = checkInput && !Regex.IsMatch(input[i], @"^[0-9]+$");
                
                if (checkInput)
                {
                    return false;
                }

                if (i > 1)
                {
                    if (Regex.IsMatch(input[i], @"^[a-zA-Z]+$"))
                    {
                        if (!inputCharacters.ContainsKey(input[i]))
                        {
                            Console.WriteLine(input[i] + " is not yet initialized. Please, initialize it.");
                            return false;
                        }
                    }
                }
            }

            return true;
        }

        #endregion

        #region INFIX EVALUATION

        //Complexity - O(n)
        String[] InfixToPostFixExpression(String[] inputArray)
        {
            Stack<String> stck = null;
            String[] resultArray = null;
            try
            {
                stck = new Stack<String>();
                resultArray = new String[inputArray.Length - 2];

                int k = -1;
                string gtKey = null;

                for (int i = 2; i < inputArray.Length; ++i)
                {
                    //Check if it is a incrementoperator or decrement
                    if (CheckIncrementDecrementOperator(inputArray[i]))
                    {
                        if (inputArray[i][0].Equals('+') || inputArray[i][0].Equals('-'))
                        {
                            gtKey = inputArray[i].Substring(2, inputArray[i].Length - 2);
                            if (inputCharacters.ContainsKey(gtKey))
                            {
                                inputCharacters[gtKey] = (inputArray[i][0].Equals('-')) ? inputCharacters[gtKey] - 1 : inputCharacters[gtKey] + 1;
                                resultArray[++k] = inputCharacters[gtKey].ToString();
                            }
                            else
                            {
                                resultArray[++k] = "0";
                            }
                           
                        }
                        else
                        {
                            gtKey = inputArray[i].Substring(0, inputArray[i].Length - 2);
                            if (inputCharacters.ContainsKey(gtKey))
                            {
                                resultArray[++k] = inputCharacters[gtKey].ToString();
                                inputCharacters[gtKey] = (inputArray[i][inputArray[i].Length - 1].Equals('-')) ? inputCharacters[gtKey] - 1 : inputCharacters[gtKey] + 1;
                            }
                            else
                            {
                                resultArray[++k] = "0";
                            }
                        }
                    }
                    else if (!CheckArithmetic(inputArray[i]))
                    {
                        resultArray[++k] = inputArray[i];
                    }
                    else if (inputArray[i] == "(")
                    {
                        stck.Push(inputArray[i]);
                    }
                    else if (inputArray[i] == ")")
                    {
                        while (stck != null && stck.Count > 0 && stck.Peek() != "(")
                            resultArray[++k] = stck.Pop();
                        if (stck != null && stck.Count > 0 && stck.Peek() != "(")
                            return null;
                        else
                            stck.Pop();
                    }
                    else
                    {
                        while (stck != null && stck.Count > 0 && Precedence(inputArray[i]) <= Precedence(stck.Peek()))
                            resultArray[++k] = stck.Pop();
                        stck.Push(inputArray[i]);
                    }
                }

                gtKey = null;

                while (stck != null && stck.Count > 0)
                    resultArray[++k] = stck.Pop();
            }
            catch (Exception exe)
            {
                Console.WriteLine(exe);
            }
            finally
            {
                stck = null;
            }

            return resultArray;
        }

        #endregion

        #region POSTFIX EVALUATION
        //Complexity - O(n)
       
        int EvaluatePostFixExpression(String[] inputArray)
        {
            Stack<int> stck = null;
            String[] postFixArray = null;
            try
            {
                postFixArray = InfixToPostFixExpression(inputArray);

                stck = new Stack<int>();

                int i;

                int res;

                for (i = 0; i < postFixArray.Length; ++i)
                {
                    if (!CheckArithmetic(postFixArray[i]))
                    {
                        if (Int32.TryParse(postFixArray[i], out res))
                        {
                            stck.Push(res);
                        }
                        else
                        {
                            stck.Push(inputCharacters[postFixArray[i]]);
                        }
                    }
                    else
                    {
                        if (stck != null && stck.Count > 0)
                        {
                            int val1 = Convert.ToInt32(stck.Pop());
                            int val2 = Convert.ToInt32(stck.Pop());

                            switch (postFixArray[i])
                            {
                                case "+": stck.Push(val2 + val1);
                                    break;
                                case "-": stck.Push(val2 - val1);
                                    break;
                                case "*": stck.Push(val2 * val1);
                                    break;
                                case "/": stck.Push(val2 / val1);
                                    break;
                                case "%": stck.Push(val2 % val1);
                                    break;
                            }
                        }
                    }
                }
            }
            catch (Exception exe)
            {
                Console.WriteLine(exe);
            }
            finally
            {
                postFixArray = null;
            }

            return (int)stck.Pop();
        }

        #endregion

        #region DISPLAY RESULTS

        void Display()
        {
            if (inputCharacters != null && inputCharacters.Count > 0)
            {
                int count = inputCharacters.Count;
                if (count > 0)
                {
                    Console.Write("(");

                    int chk = 1;

                    //Print Dictionary
                    foreach (KeyValuePair<String, Int32> record in inputCharacters)
                    {
                        if (chk == count)
                        {
                            Console.Write(record.Key + "=" + record.Value);
                        }
                        else
                        {
                            Console.Write(record.Key + "=" + record.Value + ",");
                            chk++;
                        }
                    }

                    Console.Write(")" + "\n");
                    Console.WriteLine("Press <Return> To Exit..");
                    Console.ReadLine();
                }
            }
        }

        #endregion
    }
}
