﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace TextBasedCalculator
{

    /* CONSTRAINTS:
     * Each input will be in the form of <alphabet> = <number>/<alphabet>/<series of numbers with alphabets and operators>.
     * Each alphabet is an ASCII characters or it can be string of characters.
     * Each number is an integer type i.e. INT32. Hence the range doesnot extend the integer type range.
     * the arithmetic operators used are +,-,*,/,^.
     * Use of increment and decrement operators as well.
     * All the inputs will be in series and the output contains the final values of all the string of characters values.
     */

    /* Idea:
     * Use of Hash to store the stringofcharacters as keys and the values being computed as value. This will make sure the memory occupied will
     * be as per the number of unique keys. THe hashfunction will be the default hash function used by c#.
     * The use of infix and postfix for computing the arithmetic calculations as we need to keep the order of preferences for each arithmetic operator.
     * In order to compute infix and postfix, we will use stack data struture.
     * Once, the computation is done, we will store the final computed value for that key in the hash. If the value already exists, we will update it or add it.
     */

    /* Complexities: 
     * Space Complexity: O(k) if they are k keys for hash to be stored if K is a number, the space complexity will be O(1).
     * Time Complexity: O(K*n) if they are K inputs, since K is a number. Overall Complexity - O(n).
     */

    /* FOLLOWING ARE THE TEST CASES
     * NOT A VALID INPUT:
     * 9
     * 9 = 0
     * = * ()
     * = 9 0
     * = 9 I
     * ++ i j
     * ++i
     * i = j //if it is the first statament with out j being initialized
     * 9 = i j * k
     * i = j + k //if it the first statement with out j and k being initialized
     * 
     * VALID INPUT:
     * i = 0
     * j = 10
     * k = i + j
     * 
     * j = 10
     * i = j * 100 + 20 * 30 + 40
     * 
     * k = 0
     * i = 20
     * j = 120
     */

    class Calculator
    {
        static Dictionary<String,Int32> inputCharacters;

        static void IntroductoryDetails()
        {
            Console.WriteLine("Text Based Calculator");
            Console.WriteLine("Ensure the following:");
            Console.WriteLine("1. Each Line will contain a series of strings separated by space. Ex: i = 10; k = i + j");
            Console.WriteLine("If want to view the final result, Please click on <Enter>");
        }

        /*
        static void Main(string[] args)
        {
            String input;
            String[] nwString = null;
            try
            {
                IntroductoryDetails();

                inputCharacters = new Dictionary<String,Int32>();

                //GET Each Input From Command Line
                input = Console.ReadLine();
                int res;

                while (input != null && input.Length > 0)
                {
                    nwString = input.Split(' ');

                    if (nwString.Length < 3)
                    {
                        Console.WriteLine("Not A Valid Input!..Please, Enter A Valid Input.");
                    }
                    else
                    {
                        if (ValidateInput(nwString, inputCharacters))
                        {
                            #region THREEVALUESINEXPRESSION
                            if (nwString.Length == 3)
                            {
                                if (!Int32.TryParse(nwString[2], out res))
                                {
                                    //Check if the expression is increment operator or decrement operator
                                    if (CheckIncrementDecrementOperator(nwString[2]))
                                    {
                                        char ch = nwString[2][0];
                                        int nwValue = 0;

                                        if (ch.Equals('+') || ch.Equals('-'))
                                        {
                                            nwValue = (ch.Equals('+')) ? inputCharacters[nwString[2][2].ToString()] + 1 : inputCharacters[nwString[2][2].ToString()] - 1;
                                            
                                            if (inputCharacters.ContainsKey(ch.ToString()))
                                            {
                                                inputCharacters[nwString[0]] = nwValue;
                                            }
                                            else
                                            {
                                                inputCharacters.Add(nwString[0], nwValue);
                                            }

                                            inputCharacters[nwString[2][2].ToString()] = nwValue;
                                        }
                                        else
                                        {
                                            if (inputCharacters.ContainsKey(ch.ToString()))
                                            {
                                                inputCharacters[nwString[0]] = inputCharacters[nwString[2][0].ToString()];
                                            }
                                            else
                                            {
                                                inputCharacters.Add(nwString[0], inputCharacters[nwString[2][0].ToString()]);
                                            }

                                            inputCharacters[nwString[2][0].ToString()] = (nwString[2][2].Equals('+')) ? inputCharacters[nwString[2][0].ToString()] + 1 : inputCharacters[nwString[2][0].ToString()] - 1;
                                        }
                                    }
                                    else
                                    {
                                        if (inputCharacters.ContainsKey(nwString[0]))
                                        {
                                            inputCharacters[nwString[0]] = inputCharacters[nwString[2]];
                                        }
                                        else
                                        {
                                            inputCharacters.Add(nwString[0], inputCharacters[nwString[2]]);
                                        }
                                    }
                                }
                                else
                                {
                                    if (inputCharacters.ContainsKey(nwString[0]))
                                    {
                                        inputCharacters[nwString[0]] = Convert.ToInt32(nwString[2]);
                                    }
                                    else
                                    {
                                        inputCharacters.Add(nwString[0], Convert.ToInt32(nwString[2]));
                                    }
                                }
                            }
                            #endregion
                            #region MORETHANTHREE
                            else
                            {
                                SetIncrementDecrementValues(nwString, inputCharacters);

                                if (inputCharacters.ContainsKey(nwString[0]))
                                {
                                    if (CheckMultipleOperators(nwString[1]))
                                    {
                                        inputCharacters[nwString[0]] = EvaluatePostFixExpression(GetNewString(nwString));
                                    }
                                    else
                                    {
                                        inputCharacters[nwString[0]] = EvaluatePostFixExpression(nwString);
                                    }
                                }
                                else
                                {
                                    if (CheckMultipleOperators(nwString[1]))
                                    {
                                        inputCharacters.Add(nwString[0], EvaluatePostFixExpression(GetNewString(nwString)));
                                    }
                                    else
                                    {
                                        inputCharacters.Add(nwString[0], EvaluatePostFixExpression(nwString));
                                    }
                                }
                            }
                            #endregion
                        }
                        else
                        {
                            Console.WriteLine("Not A Valid Input!..Please, Enter A Valid Input.");
                        }
                    }

                    input = Console.ReadLine();
                }

                #region DISPLAYVALUES
                int count = inputCharacters.Count;

                if (count > 0)
                {
                    Console.Write("(");

                    int chk = 1;

                    //Print Dictionary
                    foreach (KeyValuePair<String, Int32> record in inputCharacters)
                    {
                        if (chk == count)
                        {
                            Console.Write(record.Key + "=" + record.Value);
                        }
                        else
                        {
                            Console.Write(record.Key + "=" + record.Value + ",");
                            chk++;
                        }
                    }

                    Console.Write(")");
                    Console.ReadLine();
                }

                #endregion
            }
            catch (Exception exe)
            {
                Console.WriteLine(exe);
            }
            finally
            {
                input = null;
                nwString = null;
            }
        }
        */
        static bool CheckIncrementDecrementOperator(String s)
        {
            return (s.Contains("++") || s.Contains("--"));
        }

        static bool CheckMultipleOperators(String s)
        {
            return (s.Contains("+=") || s.Contains("-=") || s.Contains("*=") || s.Contains("/=") || s.Contains("%=") || s.Contains("^="));
        }

        static String[] GetNewString(String[] input)
        {
            String[] nwString = new String[input.Length + 1];

            try
            {
                for (int i = 0; i < nwString.Length; i++)
                {
                    if (i == 1)
                    {
                        nwString[i] = "=";
                        nwString[i + 1] = input[0];
                        nwString[i + 2] = input[1].ToCharArray()[0].ToString();
                        i = i + 2;
                    }
                    else
                    {
                        nwString[i] = input[i];
                    }
                }
            }
            catch (Exception exe)
            {
                Console.WriteLine(exe);
            }

            return nwString;
        }

        static bool VerifyArithmetics(string input)
        {
            return (input == "+" || input == "-" || input == "*" || input == "/" || input == "%" || input == "^");
        }

        static int Precedence(string ch)
        {
            switch (ch)
            {
                case "+":
                case "-":
                    return 1;
                case "*":
                case "/":
                case "%":
                    return 2;
                case "^":
                    return 3;
            }

            return -1;
        }

        //Complexity - O(n)
        static String[] InfixToPostFixExpression(String[] inputArray)
        {
            Stack<String> stck = null;
            String[] resultArray = null;
            try
            {
                stck = new Stack<String>();
                resultArray = new String[inputArray.Length - 2];

                int k = -1;

                for (int i = 2; i < inputArray.Length; ++i)
                {
                    //Check if it is a incrementoperator or decrement
                    if (CheckIncrementDecrementOperator(inputArray[i]))
                    {
                        if (inputArray[i][0].Equals('+') || inputArray[i][0].Equals('-'))
                        {
                            resultArray[++k] = inputArray[i][2].ToString();
                        }
                        else
                        {
                            resultArray[++k] = inputArray[i][0].ToString();
                        }
                    }
                    else if (!VerifyArithmetics(inputArray[i]))
                    {
                        resultArray[++k] = inputArray[i];
                    }
                    else if (inputArray[i] == "(")
                        stck.Push(inputArray[i]);
                    else if (inputArray[i] == ")")
                    {
                        while (stck != null && stck.Count > 0 && stck.Peek() != "(")
                            resultArray[++k] = stck.Pop();
                        if (stck != null && stck.Count > 0 && stck.Peek() != "(")
                            return null;               
                        else
                            stck.Pop();
                    }
                    else
                    {
                        while (stck != null && stck.Count > 0 && Precedence(inputArray[i]) <= Precedence(stck.Peek()))
                            resultArray[++k] = stck.Pop();
                        stck.Push(inputArray[i]);
                    }
                }

                while (stck != null && stck.Count > 0)
                    resultArray[++k] = stck.Pop();
            }
            catch (Exception exe)
            {
                Console.WriteLine(exe);
            }
            finally
            {
                stck = null;
            }

            return resultArray;
        }

        //Complexity - O(n)
        static int EvaluatePostFixExpression(String[] inputArray)
        {
            Stack<int> stck = null;
            String[] postFixArray = null;
            try
            {
                postFixArray = InfixToPostFixExpression(inputArray);

                stck = new Stack<int>();

                int i;

                int res;

                for (i = 0; i < postFixArray.Length; ++i)
                {
                    if (!VerifyArithmetics(postFixArray[i]))
                    {
                        if (Int32.TryParse(postFixArray[i], out res))
                        {
                            stck.Push(res);
                        }
                        else
                        {
                            stck.Push(inputCharacters[postFixArray[i]]);
                        }
                    }
                    else
                    {
                        if (stck != null && stck.Count > 0)
                        {
                            int val1 = Convert.ToInt32(stck.Pop());
                            int val2 = Convert.ToInt32(stck.Pop());

                            switch (postFixArray[i])
                            {
                                case "+": stck.Push(val2 + val1);
                                    break;
                                case "-": stck.Push(val2 - val1);
                                    break;
                                case "*": stck.Push(val2 * val1);
                                    break;
                                case "/": stck.Push(val2 / val1);
                                    break;
                                case "%": stck.Push(val2 % val1);
                                    break;
                            }
                        }
                    }
                }
            }
            catch (Exception exe)
            {
                Console.WriteLine(exe);
            }
            finally
            {
                postFixArray = null;
            }

            return (int)stck.Pop();
        }

        static bool ValidateInput(String[] input, Dictionary<String, Int32> inputCharacters)
        {
            if (!Regex.IsMatch(input[0], @"^[a-zA-Z]+$"))
            {
                return false;
            }

            for (int i = 1; i < input.Length; i++)
            {
                //Check If It is Arithmetic
                if (input[i] != "=" && !VerifyArithmetics(input[i]) && !CheckMultipleOperators(input[i]) && !CheckIncrementDecrementOperator(input[i])
                    && !Regex.IsMatch(input[i], @"^[a-zA-Z]+$") && !Regex.IsMatch(input[i], @"^[0-9]+$"))
                {
                    return false;
                }

                if (i > 1)
                {
                    if (Regex.IsMatch(input[i], @"^[a-zA-Z]+$"))
                    {
                        if (!inputCharacters.ContainsKey(input[i]))
                        {
                            Console.WriteLine(input[i] + " is not yet initialized. Please, initialize it.");
                            return false;
                        }
                    }
                }
            }

            return true;
        }

        static void SetIncrementDecrementValues(String[] nwString, Dictionary<String, Int32> inputCharacters)
        {
            for (int i = 2; i < nwString.Length; i++)
            {
                if (CheckIncrementDecrementOperator(nwString[i]))
                {
                    if (nwString[i][0].Equals('+') || nwString[i][0].Equals('-'))
                    {
                        inputCharacters[nwString[i][2].ToString()] = (nwString[i][0].Equals('+')) ? inputCharacters[nwString[i][2].ToString()] + 1 : inputCharacters[nwString[i][2].ToString()] - 1;
                    }
                    else
                    {
                        inputCharacters[nwString[i][0].ToString()] = (nwString[i][2].Equals('+')) ? inputCharacters[nwString[i][0].ToString()] + 1 : inputCharacters[nwString[i][0].ToString()] - 1;
                    }
                }
            }
        }
    }
}

